using PharmacyManagementSystem.DAL;
using PharmacyManagementSystem.Models;

namespace PharmacyManagementSystem.BLL;

// BLL: contains pharmacy rules/calculations. It does not read Console or files.
public class PharmacyService
{
    private readonly IPharmacyRepository _repository;
    private readonly PharmacyData _data;

    public PharmacyService(IPharmacyRepository repository)
    {
        _repository = repository;
        _data = _repository.Load();
    }

    private void SaveChanges()
    {
        _repository.Save(_data);
    }

    private Medicine? FindMedicine(string name)
    {
        return _data.Medicines.FirstOrDefault(
            medicine => string.Equals(medicine.Name, name, StringComparison.OrdinalIgnoreCase));
    }

    public List<Medicine> GetMedicines()
    {
        return _data.Medicines;
    }

    public Medicine? SearchMedicine(string name)
    {
        return FindMedicine(name);
    }

    public string AddOrUpdateStock(string name, decimal purchasePrice, decimal sellingPrice,
        int stock, int existingMedicineOption = 0, int quantity = 0)
    {
        Medicine? medicine = FindMedicine(name);

        if (medicine != null)
        {
            if (quantity <= 0)
                return "Enter a valid positive quantity.";

            if (existingMedicineOption == 1)
            {
                medicine.StockQuantity += quantity;
                SaveChanges();
                return "Stock Added Successfully!";
            }

            if (existingMedicineOption == 2)
            {
                if (quantity > medicine.StockQuantity)
                    return "Not enough stock available!";

                medicine.StockQuantity -= quantity;
                SaveChanges();
                return "Stock Reduced Successfully!";
            }

            return "Invalid Choice!";
        }

        if (purchasePrice < 0 || sellingPrice < 0 || stock < 0)
            return "Invalid price or stock quantity.";

        _data.Medicines.Add(new Medicine(name, purchasePrice, sellingPrice, stock));
        SaveChanges();
        return "New Medicine Added Successfully!";
    }

    public string UpdatePrice(string name, decimal purchasePrice, decimal sellingPrice)
    {
        Medicine? medicine = FindMedicine(name);
        if (medicine == null)
            return "Medicine Not Found!";

        if (purchasePrice < 0 || sellingPrice < 0)
            return "Invalid price.";

        medicine.PurchasePrice = purchasePrice;
        medicine.SellingPrice = sellingPrice;
        SaveChanges();
        return "Prices Updated Successfully!";
    }

    public string DeleteMedicine(string name)
    {
        Medicine? medicine = FindMedicine(name);
        if (medicine == null)
            return "Medicine Not Found!";

        _data.Medicines.Remove(medicine);
        SaveChanges();
        return "Medicine Deleted Successfully!";
    }

    public List<Medicine> GetLowStockMedicines()
    {
        return _data.Medicines.Where(medicine => medicine.StockQuantity < 20).ToList();
    }

    public string PurchaseMedicine(string name, int quantity, out decimal bill,
        out decimal pricePerUnit)
    {
        bill = 0;
        pricePerUnit = 0;

        Medicine? medicine = FindMedicine(name);
        if (medicine == null)
            return "Medicine Not Found!";

        if (quantity <= 0)
            return "Enter a valid positive quantity.";

        if (quantity > medicine.StockQuantity)
            return "Insufficient Stock!";

        bill = quantity * medicine.SellingPrice;
        decimal cost = quantity * medicine.PurchasePrice;
        pricePerUnit = medicine.SellingPrice;

        medicine.StockQuantity -= quantity;
        _data.TotalProfit += bill - cost;
        SaveChanges();

        return "Purchase Successful!";
    }

    public decimal GetTotalProfit()
    {
        return _data.TotalProfit;
    }
}
