using PharmacyManagementSystem.BLL;
using PharmacyManagementSystem.DAL;
using PharmacyManagementSystem.UI;

namespace PharmacyManagementSystem;

internal class Program
{
    static void Main()
    {
        IPharmacyRepository repository = new FilePharmacyRepository("pharmacy.txt");
        PharmacyService service = new PharmacyService(repository);
        PharmacyUI ui = new PharmacyUI(service);

        ui.Run();
    }
}
