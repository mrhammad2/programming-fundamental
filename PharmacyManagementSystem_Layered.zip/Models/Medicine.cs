namespace PharmacyManagementSystem.Models;

public class Medicine
{
    public string Name { get; set; }
    public decimal PurchasePrice { get; set; }
    public decimal SellingPrice { get; set; }
    public int StockQuantity { get; set; }

    public Medicine(string name, decimal purchasePrice, decimal sellingPrice, int stockQuantity)
    {
        Name = name;
        PurchasePrice = purchasePrice;
        SellingPrice = sellingPrice;
        StockQuantity = stockQuantity;
    }
}
