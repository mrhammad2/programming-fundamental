namespace PharmacyManagementSystem.Models;

public class PharmacyData
{
    public List<Medicine> Medicines { get; set; } = new();
    public decimal TotalProfit { get; set; }
}
