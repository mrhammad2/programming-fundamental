using PharmacyManagementSystem.BLL;
using PharmacyManagementSystem.Models;

namespace PharmacyManagementSystem.UI;

// UI: all Console input/output and menus stay in this class.
public class PharmacyUI
{
    private readonly PharmacyService _service;

    public PharmacyUI(PharmacyService service)
    {
        _service = service;
    }

    public void Run()
    {
        while (true)
        {
            Console.WriteLine("\\n=========== PHARMACY MANAGEMENT SYSTEM ===========");
            Console.WriteLine("1. Admin Login");
            Console.WriteLine("2. Customer Menu");
            Console.WriteLine("3. Exit");
            Console.Write("Enter Choice: ");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("Invalid Choice!");
                continue;
            }

            if (choice == 1)
                AdminLogin();
            else if (choice == 2)
                PurchaseMedicine();
            else if (choice == 3)
            {
                Console.WriteLine("Program Closed.");
                break;
            }
            else
                Console.WriteLine("Invalid Choice!");
        }
    }

    private void AdminLogin()
    {
        Console.Write("Enter Username: ");
        string username = Console.ReadLine() ?? "";
        Console.Write("Enter Password: ");
        string password = Console.ReadLine() ?? "";

        if (username != "admin" || password != "123")
        {
            Console.WriteLine("Invalid Login!");
            return;
        }

        int choice;
        do
        {
            Console.WriteLine("\\n============= ADMIN PANEL =============");
            Console.WriteLine("1. View Stock");
            Console.WriteLine("2. Add/Update Stock");
            Console.WriteLine("3. Delete Medicine");
            Console.WriteLine("4. Search Medicine");
            Console.WriteLine("5. Update Prices");
            Console.WriteLine("6. Low Stock Alert");
            Console.WriteLine("7. Profit Report");
            Console.WriteLine("8. Logout");
            Console.Write("Enter Choice: ");

            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid Choice!");
                choice = 0;
                continue;
            }

            switch (choice)
            {
                case 1: ViewStock(); break;
                case 2: AddOrUpdateStock(); break;
                case 3: DeleteMedicine(); break;
                case 4: SearchMedicine(); break;
                case 5: UpdatePrices(); break;
                case 6: LowStockAlert(); break;
                case 7: ProfitReport(); break;
                case 8: Console.WriteLine("Logged Out!"); break;
                default: Console.WriteLine("Invalid Choice!"); break;
            }
        } while (choice != 8);
    }

    private void ViewStock()
    {
        Console.WriteLine("\\n================ STOCK REPORT ================");
        Console.WriteLine("{0,-15}{1,-12}{2,-12}{3,-10}", "Medicine", "Buy", "Sell", "Stock");

        foreach (Medicine medicine in _service.GetMedicines())
        {
            Console.WriteLine("{0,-15}{1,-12}{2,-12}{3,-10}",
                medicine.Name, medicine.PurchasePrice, medicine.SellingPrice, medicine.StockQuantity);
        }

        Console.WriteLine("\\nTotal Profit: " + _service.GetTotalProfit());
    }

    private void SearchMedicine()
    {
        Console.Write("Enter Medicine Name: ");
        string name = Console.ReadLine() ?? "";
        Medicine? medicine = _service.SearchMedicine(name);

        if (medicine == null)
        {
            Console.WriteLine("Medicine Not Found!");
            return;
        }

        Console.WriteLine("\\nMedicine Found:");
        Console.WriteLine("Name: " + medicine.Name);
        Console.WriteLine("Purchase Price: " + medicine.PurchasePrice);
        Console.WriteLine("Selling Price: " + medicine.SellingPrice);
        Console.WriteLine("Stock: " + medicine.StockQuantity);
    }

    private void AddOrUpdateStock()
    {
        Console.Write("Enter Medicine Name: ");
        string name = Console.ReadLine() ?? "";

        if (_service.SearchMedicine(name) != null)
        {
            Console.WriteLine("Medicine already exists!");
            Console.WriteLine("1. Add Stock");
            Console.WriteLine("2. Reduce Stock");
            Console.Write("Enter Choice: ");

            if (!int.TryParse(Console.ReadLine(), out int option) || (option != 1 && option != 2))
            {
                Console.WriteLine("Invalid Choice!");
                return;
            }

            Console.Write("Enter Quantity: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity <= 0)
            {
                Console.WriteLine("Enter a valid positive quantity.");
                return;
            }

            Console.WriteLine(_service.AddOrUpdateStock(name, 0, 0, 0, option, quantity));
        }
        else
        {
            Console.Write("Enter Purchase Price: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal purchasePrice) || purchasePrice < 0)
            {
                Console.WriteLine("Invalid purchase price.");
                return;
            }

            Console.Write("Enter Selling Price: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal sellingPrice) || sellingPrice < 0)
            {
                Console.WriteLine("Invalid selling price.");
                return;
            }

            Console.Write("Enter Stock Quantity: ");
            if (!int.TryParse(Console.ReadLine(), out int stock) || stock < 0)
            {
                Console.WriteLine("Invalid stock quantity.");
                return;
            }

            Console.WriteLine(_service.AddOrUpdateStock(name, purchasePrice, sellingPrice, stock));
        }
    }

    private void UpdatePrices()
    {
        Console.Write("Enter Medicine Name: ");
        string name = Console.ReadLine() ?? "";

        Console.Write("Enter New Purchase Price: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal purchasePrice) || purchasePrice < 0)
        {
            Console.WriteLine("Invalid purchase price.");
            return;
        }

        Console.Write("Enter New Selling Price: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal sellingPrice) || sellingPrice < 0)
        {
            Console.WriteLine("Invalid selling price.");
            return;
        }

        Console.WriteLine(_service.UpdatePrice(name, purchasePrice, sellingPrice));
    }

    private void DeleteMedicine()
    {
        Console.Write("Enter Medicine Name: ");
        string name = Console.ReadLine() ?? "";
        Console.WriteLine(_service.DeleteMedicine(name));
    }

    private void LowStockAlert()
    {
        Console.WriteLine("\\n===== LOW STOCK ALERT =====");
        List<Medicine> lowStock = _service.GetLowStockMedicines();

        if (lowStock.Count == 0)
        {
            Console.WriteLine("No medicines are currently low in stock.");
            return;
        }

        foreach (Medicine medicine in lowStock)
            Console.WriteLine(medicine.Name + " -> Only " + medicine.StockQuantity + " left");
    }

    private void PurchaseMedicine()
    {
        Console.WriteLine("\\nAvailable Medicines:");
        foreach (Medicine medicine in _service.GetMedicines())
        {
            Console.WriteLine(medicine.Name + " | Price: " + medicine.SellingPrice +
                              " | Stock: " + medicine.StockQuantity);
        }

        Console.Write("\\nEnter Medicine Name: ");
        string name = Console.ReadLine() ?? "";

        Console.Write("Enter Quantity: ");
        if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity <= 0)
        {
            Console.WriteLine("Enter a valid positive quantity.");
            return;
        }

        string result = _service.PurchaseMedicine(name, quantity, out decimal bill,
            out decimal pricePerUnit);

        Console.WriteLine(result);

        if (result == "Purchase Successful!")
        {
            Console.WriteLine("\\n========= CUSTOMER BILL =========");
            Console.WriteLine("Medicine: " + name);
            Console.WriteLine("Quantity: " + quantity);
            Console.WriteLine("Price Per Unit: " + pricePerUnit);
            Console.WriteLine("Total Bill: " + bill);
        }
    }

    private void ProfitReport()
    {
        Console.WriteLine("\\n===== PROFIT REPORT =====");
        Console.WriteLine("Total Pharmacy Profit: " + _service.GetTotalProfit());
    }
}
