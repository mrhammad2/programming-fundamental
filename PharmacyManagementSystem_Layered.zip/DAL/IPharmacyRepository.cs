using PharmacyManagementSystem.Models;

namespace PharmacyManagementSystem.DAL;

public interface IPharmacyRepository
{
    PharmacyData Load();
    void Save(PharmacyData data);
}
