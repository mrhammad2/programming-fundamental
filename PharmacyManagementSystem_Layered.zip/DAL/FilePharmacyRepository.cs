using System.Globalization;
using PharmacyManagementSystem.Models;

namespace PharmacyManagementSystem.DAL;

// Repository / DAL: this class is responsible only for reading and writing the file.
public class FilePharmacyRepository : IPharmacyRepository
{
    private readonly string _fileName;

    public FilePharmacyRepository(string fileName)
    {
        _fileName = fileName;
    }

    public PharmacyData Load()
    {
        PharmacyData data = new PharmacyData();

        if (!File.Exists(_fileName))
        {
            data.Medicines.AddRange(new[]
            {
                new Medicine("Panadol", 10, 15, 100),
                new Medicine("Arinac", 50, 70, 50),
                new Medicine("Brufen", 30, 45, 80),
                new Medicine("Disprin", 5, 10, 200),
                new Medicine("Flagyl", 40, 60, 40)
            });

            Save(data);
            return data;
        }

        try
        {
            string[] lines = File.ReadAllLines(_fileName);
            if (lines.Length == 0)
                return data;

            data.TotalProfit = decimal.Parse(lines[0], CultureInfo.InvariantCulture);

            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split('|');
                if (parts.Length == 4 &&
                    decimal.TryParse(parts[1], NumberStyles.Number, CultureInfo.InvariantCulture, out decimal purchasePrice) &&
                    decimal.TryParse(parts[2], NumberStyles.Number, CultureInfo.InvariantCulture, out decimal sellingPrice) &&
                    int.TryParse(parts[3], out int stock))
                {
                    data.Medicines.Add(new Medicine(parts[0], purchasePrice, sellingPrice, stock));
                }
            }
        }
        catch (Exception)
        {
            // Return an empty data object if the file is damaged or unreadable.
            return new PharmacyData();
        }

        return data;
    }

    public void Save(PharmacyData data)
    {
        using StreamWriter file = new StreamWriter(_fileName);
        file.WriteLine(data.TotalProfit.ToString(CultureInfo.InvariantCulture));

        foreach (Medicine medicine in data.Medicines)
        {
            file.WriteLine(
                medicine.Name + "|" +
                medicine.PurchasePrice.ToString(CultureInfo.InvariantCulture) + "|" +
                medicine.SellingPrice.ToString(CultureInfo.InvariantCulture) + "|" +
                medicine.StockQuantity);
        }
    }
}
